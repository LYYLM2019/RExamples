#include <arma.h> 

#ifndef GARCH_INCLUDED
#define GARCH_INCLUDED
	
#include <database.h>
#include <modelbase.h>
#include <maximize.h>


enum
{
	Y_VAR, X_VAR, Z_VAR 	
};
enum // estimation types
{
    M_HESS, M_CROSSPRODUCT, M_QMLE, M_TESTS 
};
enum // model classes					   
{
	MC_STATS, MC_GARCH, MC_SIMUL
};

enum
{
	RiskMETRICS, GARCH, EGARCH, GJR, APARCH, IGARCH, FIGARCH_BBM, FIGARCH_CHUNG, FIEGARCH, FIAPARCH_BBM, FIAPARCH_CHUNG, HYGARCH
};

class Garch : Modelbase			
{

public:
	decl m_iModelClass;		// Model class
    decl m_cOxPack;     // 1 for oxpack session
	decl m_iMethod_VC;		// M_HESS, M_CROSSPRODUCT or M_QMLE
	decl m_iMethod_VC_temp;
	decl m_mXM; 	   		// Regressor in the Mean matrix [cT][m_cX]
	decl m_mXV; 	   		// Regressor in the Variance matrix [cT][m_cX]
	decl m_vE;      		// Residuals [cT][1]
	decl m_vE2;     		// Squared residuals [cT][1]
	decl m_vMean; 			// Conditional mean	[cT][1]
	decl m_vSigma2; 		// Conditional variance	[cT][1]
	decl m_cNeg;			// Number of observation with a negative variance
	decl m_cYsmall; 		// Used to avoid the "too small m_calpha0" problem during convergence. // NEW
	decl m_cVar_target; 	// 1 to apply the variance targeting method, 0 otherwize // NEW	  
	decl m_cT;       		// number of observations 
	decl m_cEst;
	decl m_cY;       		// number of dependent variables (always 1 here) 
	decl m_cXM;      		// number of regressors in the mean equation (if any)
	decl m_cXV;      		// number of regressors in the variance (if any)
	decl m_cMean; 			// 1 if there is a constant in the mean, 0 otherwise 
	decl m_cVar;			// 1 if there is a constant in the variance, 0 otherwise 
	 
	decl m_cDist;   		// Distribution (0:Normal, 1: Student-t, 2: GED, 3: Skewed Student-t)
	decl m_cV;      		// Kurtosis Coefficient (Student & GED deg.of freedom) 
	decl m_cA;				// Skewness Coefficient
	decl m_cSk;				// 1 if Skewness related parameter to be estimated, 0 otherwise  
	decl m_cKu;				// 1 if Kurtosis related parameter to be estimated, 0 otherwise 
	
	decl m_cAR;       		// Auto-Regressive order p for ARMA(p,q) specification in the mean 
	decl m_cMA; 			// Moving Average order q for ARMA(p,q) specification in the mean
	decl m_cARFI;			// 1 if ARFIMA(p,d,q), 0 if ARMA(p,q)
	
	decl m_clevel;  		// Constant in the mean  
	decl m_vbetam;			// Coefficients of the regressors in the mean equation [m_cXM][1]
	decl m_vAR;				// AR Coefficients [m_cAR][1] 
	decl m_vMA;				// MA Coefficients [m_cMA][1]
	decl m_vAR_MA;      	// AR|MA Coefficients [m_cAR+m_cMA][1] 
	decl m_dARFI;			// Value of the FI term in ARFIMA(p,d,q) (need m_cARFI = 1).
	  
	decl m_cP;	   			// Order p for Garch effects in GARCH(p,q) specification in the cond.variance
	decl m_cQ;	   			// Order q for Arch effects in GARCH(p,q) specification in the cond.variance
	decl m_cD;	   			// 1 if Fractional Integration wanted, 0 otherwise  
	decl m_claglamb;		// Truncation Order
	decl m_cIGARCH; 		// 1 if IGARCH(p,q), 0 otherwise 
	decl m_cGJR;			// 1 if GJR(p,q), 0 otherwise
	decl m_cHY;         	// 1 if HYGARCH, 0 otherwise 
	decl m_cEgarch;			// 1 if EGARCH(p,q), 0 otherwise 
	decl m_cAparch;			// 1 if APARCH(p,q), 0 otherwise 
	decl m_cMod;			// Model specification (either a string or an integer)
							// 0 : RISKMETRICS 		1 : GARCH			2 : EGARCH 		 
							// 3 : GJR	 			4 : APARCH			5 : IGARCH		  
							// 6 : FIGARCH-BBM		7 : FIGARCH-CHUNG	8 : FIEGARCH
							// 9 : FIAPARCH-BBM 	10 : FIAPARCH-CHUNG	11 : HYGARCH	
	decl m_asModels;		// Array of strings with the different specifications (see m_cMod)
	decl m_cFilter;			// 0 : RISKMETRICS 	1 : GARCH, 	10 : IGARCH, 	11 : FIGARCH(BBM), 		12: FIGARCH(Chung),	 13: RiskMetrics
							// 2 : EGARCH, 									21 : FIEGARCH (BBM),  
							// 3 : GJR,
							// 4 : APARCH, 									41 : FIAPARCH (BBM), 	42 : FIAPARCH (Chung).
				 			// 			   									51 : HYGARCH (BBM). 	
	decl m_c_in_mean;     	// 1 to add the var in the mean equation, 2 for the std, 0 otherwize					
	
	decl m_calpha0;			// Constant in the variance
	decl m_vpsyv;	  		// Coefficients of the regressors in the variance equation [m_cXV][1]
	decl m_dD;	   			// Value (double) of the FI term in FIGARCH(p,d,q) (need m_cD = 1).
	decl m_vbetav;			// Parameters of the lags of the cond.variance (cond.variance equation) [m_cP][1]
	decl m_valphav;			// Parameters of the lags of the residuals (cond.variance equation) [m_cQ][1]
	decl m_vleverage; 		// Leverage coefficient(s) (GJR)
	decl m_vtheta1;   		// (FI)EGARCH coefficient
	decl m_vtheta2;   		// (FI)EGARCH coefficient
	decl m_vgamma;			// Gamma coefficient - (FI)APARCH
	decl m_ddelta;			// Delta coefficient - (FI)APARCH
	decl m_vHY;				// HYGARCH coefficient alpha
	decl m_v_in_mean;   	// ARCH-in-mean parameter
	decl m_dRMbeta;	    	// Fixed beta for the RiskMetrics model 
	decl m_vConstr;
	decl remove_checkPara_GARCH;
	decl m_cPar; 			// Number of parameters to be estimated ( = m_cMean + m_cXM + m_cARFI + m_cAR + m_cMA + m_cVar + m_cXV + m_cD + m_cP + m_cQ + m_cGJR*m_cQ + 2*m_cEgarch + m_cAparch*(m_cQ+1) + m_cSk + m_cKu)
	decl m_vPar;	   		// Parameters vector [m_cPar][1]
							// m_vPar = m_clevel | m_vbetam |  m_dARFI | m_vAR | m_vMA | m_calpha0 | m_vgammav | m_dD |  m_vbetav | m_valphav | m_vleverage | m_vtheta1 | m_vtheta2 | m_vpsy | m_ddelta | m_cA | m_cV  
	
	decl m_mBound;			// Bounds matrice [m_cPar][2]
	decl m_cBound;			// 1 if bounded parameters used, 0 otherwise
	  
	decl m_cMLE;			// 1 : MLE, 2 : QMLE, 0 : Both
	decl m_MaxSA;			// 1 to use the MaxSA algorithm
	decl m_dT,m_dRt, m_iNS,m_iNT, m_vC, m_vM; // see MaxSA variables
	
	decl m_cRobustLL;		// if 0 -> return the sum of likelihood in FigLL, if 1 -> return the likelihood vector
	decl m_vGrad;			// Gradients 
	decl m_vStdErrors;		// Standard Errors	  [m_cPar][1]
	decl m_vStandErrors; 	// Standardized Residuals	  [cT][1]
	decl m_vSqStandErrors; 	// Squared Standardized Residuals	  [cT][1]
	decl m_cCovar;      	// 1 to print Variance Covariance Matrix, 0 otherwise		   	
	decl m_cd;          	// cdf of the standardized residuals 
	decl m_cdf;         	// cdf of the standardized residuals  	
	
	decl m_cTests;	 		// 1 to run tests on raw series (TESTSONLY function in OxEdit)  
	decl m_cLagPort;  		// Lag orders for the Box Pierce tests
	decl m_cLagArch;  		// Lag orders for Engle's LM ARCH test
	decl m_cLagRBD;		   	// Lag orders for the RGD test of TSE 
	decl m_clagged_Hit;		// Number of lagged Hit variables in the DQT
	decl m_cVaR_levels;		// VaR levels
	decl m_cVaR_levels_for;	// VaR levels for forecasts
	decl m_cVaR_for;        // 1 if VaR forecasts computed
	decl m_cVaR_for_plot;	// 1 to plot the VaR forecasts
	decl m_cVaR_forecasts;  // VaR forecasts (for the m_cVaR_levels_for levels)
	decl m_cNyblom;			// 1 if compute the Nyblom stability Test
	decl m_cSBT; 			// 1 to run the Sign Bias Test
	decl m_cGOF;        	// 1 to compute the adjusted Pearson Chi-square Goodness-of-fit test, 0 otherwise  
	decl m_cCellGOF;	   	// Number of cells for the adjusted Pearson Chi-square Goodness-of-fit test
	decl m_cFOR;			// 1 to launch the forecasting procedure
	decl m_cMethFOR;		// Number for step(s) ahead static forecast(s) 
	decl m_cTforc;			// Number of Forecasts
	decl m_mForc;			// Forecasts Matrix : Mean forecasts ~ Variance forecasts [m_cTforc][2]
	decl m_forYerror;   	// Forecast error of Y 	[m_cTforc][1]
	decl m_Yfor;        	// Observed Y corresponding to the forecasting period  [m_cTforc][1]
	decl m_Hfor;			// Observed Variance corresponding to the forecasting period  [m_cTforc][1]
	  
	decl m_cIter;			// Number of iterations between printed intermediary results (if equal 0 => no intermediary results).
	decl m_cGraphs;			// 1: Estimation Graphics, 0 : No Graphs   
	decl m_cForGraphs;		// 1: Forecasts Graphics, 0 : No Graphs
	decl m_cSGraphs;		// 1: Saves Estimation Graphics, 0 : No Graphs   				  
	decl m_cSForGraphs;		// 1: Saves Forecasts Graphics, 0 : No Graphs					  
	decl m_sNameGraphs;		// 1: Saved Estimation Graphics file name, 0 : No Graphs      
	decl m_sNameForGraphs;	// 1: Saved Forecasts Graphics file name, 0 : No Graphs       
	decl m_cStartMet; 		// in OxPack, define the way the starting values are entered
	decl m_cPrintTest;	 	// 0: no printing ;  1: prints the tests output   
	decl m_cPrintMissPTest;
	decl m_cFix;        	// 1 to fix some parameter values, 0 otherwize
	decl m_vFix;			// vector of 1's and 0's : 1 to estimate and 0 to fix (to the starting value)
	  						// the corresponding parameter (if m_cFix=1)
	decl time;				// timer();
	decl m_print_object;
	decl m_c_print_for;	 	// 1 to Print Forecasts, 0 otherwise
	decl m_c_graph_for;		// 1 to Plot Forecasts, 0 otherwise								 
	decl names_Y_stat;
	decl sample_info_stat;
	decl m_c_nonstandardized;
	decl m_c_inv_df;
	decl m_cQuantile;
	decl prbl_vartarget;
	decl m_cplot_Unc_Var;
	decl m_cprintError_Measures;
	decl m_vquan;
	decl m_cplot_raw;	   // Global variables for graphs.
	decl m_cplot_res;
	decl m_cplot_res2;
	decl m_cplot_stand_res;
	decl m_cplot_cond_mean;
	decl m_cplot_cond_var;
	decl m_cplot_hist;
	decl m_cplot_var;
	decl m_mvar_in;
	decl m_cICriterion;
	decl m_cNormality;
	decl m_cTQ;
	decl m_cTQ2;
	decl m_cRBD;
	decl m_cKupiec;
	decl m_cARCH_LM;
	decl m_cDQT;
	decl m_c_print_for_Error;
	decl m_cpre_for_plot;
	decl m_cplot_CI;
	decl m_ccritical_val_plot;
	decl m_cVR_test,m_cRS_test,m_cNVR,m_cqLo,m_cRuns_test;		

	decl m_cStore_res;
	decl m_cStore_res2;
	decl m_cStore_stand_res;
	decl m_cStore_mean;
	decl m_cStore_var;
	decl m_cStore_VaR_in;
	decl m_cStore_VaR_out;
	decl m_cStore_mean_for;
	decl m_cStore_var_for;
	decl m_cStore_confirm_name;

	decl m_cReset_Default;
	decl m_cSave_Settings;
	decl m_iModel;
	decl m_asMethods;
	decl m_iResult;

	decl m_cBasic_test;
	decl m_cNormality_test;
	decl m_cLM_ARCH_test;
	decl m_cLagArch_test;
	decl m_cBoxP_test;
	decl m_cBoxP2_test;
	decl m_cBoxP_lags_test;
	decl m_cUnit_Root_test;
	decl m_cLong_Memory_test;
	decl m_cBandwidth_test;
	decl m_c_choice_UR_test;
	decl m_c_lags_UR;

	decl m_cT_simul;
	decl m_cplot_simul;
	decl m_cstore_simul;
	decl m_cnumber_simulations;
	decl m_aname_simul_y;
	decl m_aname_simul_sigma2;
	decl m_cseed;
	decl m_cMod_simul;
	decl m_cAR_simul;
	decl m_cMA_simul;
	decl m_cP_simul;
	decl m_cQ_simul;
	decl m_cDist_simul;
	decl m_ssave_simul;

	decl m_mY_temp;
	
	
/*** Constructor - in garch_basics.ox  ***/
	Garch();
	~Garch();
	GetPackageName();
	GetPackageVersion();
	Get_T1est();
	Get_T2est();
	Append_in(const variable, const name);
	Append_out(const variable, const name);

/*** Model Formulation - in garch_input.ox ***/
	virtual CSTS(const cstM, const cstV);
	VARIANCE_TARGETING(const choice);
	DISTRI(const dist);
	ARMA_ORDERS(const cAR, const cMA);
	ARFIMA(const cARFI);					
	GARCH_ORDERS(const cP, const cQ) ;
	MODEL(const mod);								  
	ARCH_IN_MEAN(const type);
	RISKMETRICS(const lambda);
	TRUNC(const t);								 
	BOUNDS(const method);
	NORMALITY_TEST(const choice);
	INFO_CRITERIA(const choice);
	KUPIEC_TEST(const choice);
	DQT(const choice, const lags);
	VaR_LEVELS(const choice); 	
	MLE(const method);
	BOXPIERCE(const lags);
	ARCHLAGS(const lags);
	RBD(const lags);
	NYBLOM(const i);
	SBT(const i);
	PEARSON(const lags);
	FORECAST(const i, const nbforc, const iprint);
	ITER(const i);
	TESTS(const p, const a);		  	 	
	COVAR(const p);					  	 
	GRAPHS(const d, const s, const file);				 
	FOREGRAPHS(const d, const s, const file);			 
	FIXPARAM(const cfix, const fix);
	MAXSA(const maxsa, const dT,const dRt, const iNS, const iNT, const vC, const vM);
	
/*** Initialisation - in garch_input.ox ***/
	InitGlobals();
	CheckPara();
	InitData();
	InitStartValues(const init_par, const init_bounds);
	SetStartValue(const name, const stval);
	FixBounds() ;
	SetBounds(const name, const lbound, const ubound);
	ReleaseBounds(const i);	
    CheckValue(const name, const stval, const type);
	MatrixToString(const name_matrix, const val, const format);	
	
/*** Misc. - in garch_basics.ox ***/
	Pause(const sec);
	myshape(const z,const m,const r);

/*** Model Info - in garch_basics.ox ***/
	GetDistri();
	GetModelName(const mod) ; 
	GetNbPar();
	virtual GetParNames();
	GetSeries();
	GetValue(const name) ;
	GetXNames();
	GetYNames();
	GetZNames();		  	
	virtual GetcT();
	
/*** Parameters Management - in garch_estim.ox  ***/
	GetPara() ;
	SplitPara(vP) ;
	GetParEst(); 	
			  	
/*** Estimation process - in garch_estim.ox ***/
    Initialization(const vStart);
	DoEstimation(vPar);
	virtual cfunc_gt0(const avF, const vP);
	virtual FigLL(const vP, const adFunc, const avScore, const amHessian);
	FigLL2(const avF, const vP);
	virtual Res_Var();
	virtual GetRes(const y, const x);
	GetXB(const x, const n); 
	GetZB(const x, const n);

/*** Filters - in garch_filters.ox ***/
	virtual Garch_Filter(const e, const level, const p, const q, const par) ;
	GJR_Filter(const e, const level, const p, const q, const par) ;
	Aparch(const e, const level, const p, const q, const par);
	Egarch(const e, const level, const p, const q, const par, const Cst);
	Figarch_BBM(const y, const level, const p, const q, const laglamb, const par) ;
	Figarch_Chung(const e, const sm, const p, const q, const par);
	Fiegarch(const e, const level, const p, const q, const par, const laglamb, const Cst) ;
	KiAparch(const dist, const q, const par, const delta, const gamma);
	Garch_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_garch, const in_mean_type, const in_mean);
	GJR_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_gjr, const in_mean_type, const in_mean);
	Aparch_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_APARCH, const in_mean_type, const in_mean);
	Egarch_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_EGARCH, const Cst, const in_mean_type, const in_mean);
	Figarch_BBM_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_figarch, const laglamb, const in_mean_type, const in_mean);
	Figarch_Chung_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_figarch, const in_mean_type, const in_mean);
	Fiaparch_BBM_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_fiaparch, const laglamb, const in_mean_type, const in_mean);
	Fiaparch_Chung_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_fiaparch, const in_mean_type, const in_mean);
	Fiegarch_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_FIEGARCH, const laglamb, const Cst, const in_mean_type, const in_mean);

/*** Densities - in garch_densities.ox ***/
	GaussLik(const vE, const vSigma2) ;
	StudentLik(const vE, const vSigma2, const v) ;
	GEDLik(const vE, const vSigma2, const a) ;
	SkStudentLik(const vE, const vSigma2, const s, const v) ;
	CD(const e, const var, const dist, const par);
	CDFGED(const ee,const nu);  
	INVCDFGED(const p,const nu); 
	CDFTA(const ee,const logxi,const nu);
	INVCDFTA(const p,const logxi,const nu);
	mom_trst(const mu, const k);
	E_abseps(const dist, const par);
	
/*** Forecasting - in garch_forecasts.ox ***/
	GetForcData(const iGroup, const cTforc); 
	GetXBetaForc(const cTforc); 
	GetZBetaForc(const cTforc);
	GetForErrors();
	Forecasting(); 
	For_Arma(const y_l, const p, const q, const arma, const level_forc, const e);
	For_Arfima(const y_l, const p, const q, const d, const arma, const level_forc, const e);
	virtual For_Garch(const esqr, const hh, const p, const q, const alpha, const beta, const level_forc);
	For_GJR(const e, const hh, const p, const q, const alpha, const beta, const leverage, const level_forc, const prob_neg); 
	For_Aparch(const ee, const hh, const p, const q, const alpha, const beta, const gamma, const delta, const level_forc, const Ki);
	For_Egarch(const e, const hh, const p, const q, const alpha, const beta, const theta1, const theta2, const level, const Cst);
	For_Fiegarch(const e, const hh, const p, const q, const d, const alpha, const beta, const theta1, const theta2, const level, const Cst, const laglamb);
	For_Figarch_BBM(const esqr, const hh, const p, const q, const d, const alpha, const beta, const HY, const level_forc, const laglamb); 
	For_Figarch_Chung(const esqr, const hh, const p, const q, const d, const alpha, const beta, const level);
	For_Fiaparch_BBM(const e, const hh, const p, const q, const d, const alpha, const beta, const gamma, const delta, const level_forc, const laglamb, const Ki);	
	For_Fiaparch_Chung(const e, const hh, const p, const q, const d, const alpha, const beta, const gamma, const delta, const level_forc, const Ki);	
	For_Graphs(const plot, pre, const type, const valcrit,...);			
	
/*** Tests  - in garch_tests.ox***/
	PearsonTest(const cd, const ng, const np);
	Auto(const z, const ncor, const min, const max, const plot); 
	BoxPQ(const eh,const ncor,const adj);
	absha(const z,const u,const o);
	CL_Uniform(const z_series,const number_of_bins,const conf_interval, const draw, const plot);  
	FEM(const forc, const obs);
	ICriterion(const LogL, const n, const q);
	MZ(const HFor, const MatFor, const nbFor);
	Normality(const e);
	Nyblom(const grad);
	RBD_Test_mean(const e, const M,...);
	RBD_Test(const e, const M,...);
	FigLL3(const avF, const vP);
	FigLL6(const avF, const vP);

	Runs_Test(const y, const print_output,const RBD_correction);
	RBD_Skewness_Test(const Hit, const X, const names_X, const print_ols, const RBD_correction); 
	RBD_Skewness_Test_MLE(const beta, const V11, const V22, const X, const names_X,const print_ols); 
	FigLL9(const avF, const vP);
	RBD_Test_z3(const y, const M, ...);
	E_zstar_3(const xi, const mu);
	FigLL4(const avF, const vP);
	FigLL5(const avF, const vP); 	

	SignBiasTest_RBD(const res, const cvar);
	SignBiasTest(const res, const cvar);
	VaR_Test(const Y, const emp_quan_pos, const emp_quan_neg, const th_quan);
	FigLL7(const avF, const vP);
	VaR_DynQuant(const Y, const emp_quan_pos, const emp_quan_neg, const th_quan, const p, const X, const print_ols,...);
	FigLL8(const avF, const vP);
	PIT_Test(const cd, const RBD_correction);
	ADF(const series, const names_series, const lags, const option);
	KPSS(const series, const names_series, const lags,const option);
	SCHMIDT_PHILLIPS(const series,const names_series,const lags,const option);
	EstimateGPH(const mY, const iTrunc, const fPrint);
	EstimateGSP(const mY, const iTrunc, const fPrint);
	VR_test(const R, N, const print_output);
	RS_test(const R, q, const print_output);
	Runs_test(const x, const print_output);
/*** Output  - in garch_output.ox ***/
	PrintStartValues(const p);
	PrintBounds(const p);
	Output();
	MLEMeth(const par, const parnames, const name, const nbpar);   
	Stationarity(const filter) ;  										
	Positivity(const filter) ;
	virtual Covar();
	Tests();
	TestGraphicAnalysis(const ser, const res, const sqres, const stdres, const mean, const h, const hist, const plot);
	Print_VaR_out_of_sample_Forecast(const VaR_levels_for,...);
	VaR_out_of_sample(const meth, const quantile);
	VaR_in_sample(const meth, const quantile);
	QuantileGraphs(const meth, const quantile, const iplot);
	STORE(const res, const res2, const condv, const mfor, const vfor, const name, const file) ;
	SAVEPAR(const i, const file); 		  
//	GetModelLabel();  	
/*** Batch - in garch_oxpack.ox ***/	  
	GetModelLabel();
	GetMethodLabel();
	GetSettingValues();
	virtual Buffering(const iBufferOn);
	virtual BatchMethod(const sMethod);
	BatchCommands();
	virtual Batch(const sBatch, ...);
	virtual GetBatchModelSettings();
	GetBatchStoreSettings();
	GetBatchGraphicsSettings();
	GetBatchForecastsSettings();
	GetBatchTestSettings();
/*** OxPack - in garch_oxpack.ox ***/
	Estimate();
	Dialogs();
	DoLinearIneqConstrDialog();
	SendVarStatus();
	SendSpecials();
	ReceiveMenuChoice(const sDialog);
	DoTestDlg();
	DoTestGraphicsDlg();
	DoTestForecastsDlg();
	DoTestStoreDlg();
	DoOption(const sOpt, const val);
	DoEstimateDlg(const iFirstMethod, const cMethods, const sMethods, const bForcAllowed, const bRecAllowed, const bMaxDlgAllowed);
	DoTestSettingsDlg();
	DoSettingsDlg();
	DoUR_TestsDlg(const test, const series, const names);
	DoPreTestDlg();
	DoSimulationDialog();
	
	SendMethods();
	SendMenu(const sMenu);
	ReceiveData();
	ReceiveModel();
	GetModelSettings();
	SetModelSettings(const aValues);
	LoadOptions();
	SaveOptions();

	GetOxEstimate(const sObj);
	GetOxCode();
	GetOxModelSettings(const sObj);
	GetOxTestSettings(const sObj);
	GetOxGraphicsSettings(const sObj);
	GetOxForecastsSettings(const sObj);
	GetOxStoreSettings(const sObj);	
	GetOxCodePackageName();

/*** Intraday functions - in garch_intra.ox ***/
	SplitDate(const vDate);
	HourNames(const opentime, const closetime, const freq);
	Compute_Returns(const sPriceData, const ONRet);
	InterpolateMissingValues(const sPrice_FileName);
	Compute_RV(const mRet_table);
	Compute_BV(const mRet_table);
	Compute_TQ(const mRet_table);
	Compute_BVStag(const mRet_table);
	Compute_TQStag(const mRet_table);
	SigJumpZTestStat(const vRV, const vBV, const vTQ, const cPer);
	SigJumpZTestStat2(const vRV, const vBV, const vTQ, const cPer);
	Compute_LeeMykJump(const mRet_table, const siglevel, const nodrift, const k);
	
/*** Intraday functions - in garch_intra_2.ox ***/
	Simul_Wiener_process(const m, const deltat);
	Simul_Continuous_GARCH(const p_0, const s2_0, const m, const Delta, const theta, const omega, const lambda, const p, const s2);
	Simul_Continuous_GARCH_JUMPS(const p_0, const s2_0, const m, const Delta, const theta, const omega, const lambda, const dLambda, const sigma_k, const p, const s2, const k, const q);
	FFF_filter(const ret_table, const sigma_sq_daily, const J, const P, const X, const names_X);

/*** Old functions (syntax) - in garch_old_fct.ox ***/
	AParch(const e, const level, const p, const q, const par);
	APARCH_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_APARCH, const in_mean_type, const in_mean);
	APGT(const cd, const ng, const np);
	ARCH_in_mean(const type);
	AUTO(const z, const ncor, const min, const max, const plot); 
	confidence_limits_uniform (const z_series,const number_of_bins,const conf_interval, const draw, const plot);  
	EGarch(const e, const level, const p, const q, const par, const Cst);
	EGARCH_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_EGARCH, const Cst, const in_mean_type, const in_mean);
	FIAPARCH_BBM_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_fiaparch, const laglamb, const in_mean_type, const in_mean);
	FIAPARCH_Chung_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_fiaparch, const in_mean_type, const in_mean);
	FIEGarch(const e, const level, const p, const q, const par, const laglamb, const Cst) ;
	FIEGARCH_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_FIEGARCH, const laglamb, const Cst, const in_mean_type, const in_mean);
	FIGARCH_BBM_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_figarch, const laglamb, const in_mean_type, const in_mean);
	FIGARCH_Chung_in_mean(const y, const Xb_mean, const ARMA_orders, const ARMA_coef, const ARFIMA, const d_arfima, const Xb_var, const p, const q, const par_figarch, const in_mean_type, const in_mean);
	FORECASTING(); 
	FOR_ARMA(const y_l, const p, const q, const arma, const level_forc, const e);
	FOR_ARFIMA(const y_l, const p, const q, const d, const arma, const level_forc, const e);
	FOR_GARCH(const esqr, const hh, const p, const q, const alpha, const beta, const level_forc);
	FOR_GJR(const e, const hh, const p, const q, const alpha, const beta, const leverage, const level_forc, const prob_neg); 
	FOR_APARCH(const ee, const hh, const p, const q, const alpha, const beta, const gamma, const delta, const level_forc, const Ki);
	FOR_EGARCH(const e, const hh, const p, const q, const alpha, const beta, const theta1, const theta2, const level, const Cst);
	FOR_FIEGARCH(const e, const hh, const p, const q, const d, const alpha, const beta, const theta1, const theta2, const level, const Cst, const laglamb);
	FOR_FIGARCH_BBM(const esqr, const hh, const p, const q, const d, const alpha, const beta, const HY, const level_forc, const laglamb); 
	FOR_FIGARCH_Chung(const esqr, const hh, const p, const q, const d, const alpha, const beta, const level);
	FOR_FIAPARCH_BBM(const e, const hh, const p, const q, const d, const alpha, const beta, const gamma, const delta, const level_forc, const laglamb, const Ki);	
	FOR_FIAPARCH_Chung(const e, const hh, const p, const q, const d, const alpha, const beta, const gamma, const delta, const level_forc, const Ki);	
	FOR_GRAPHS(const plot, const pre, const type, const valcrit);
	For_VaR_Graphs(const plot, const VaR_forecasts, const VaR_levels_for, pre);
	Init_Globals();
	Maxsa(const maxsa, const dT,const dRt, const iNS, const iNT, const vC, const vM);
	PAR(); 
	RBD_test(const e, const M);
	VaR_test(const Y, const emp_quan_pos, const emp_quan_neg, const th_quan);

/*** Simulations - in garch_simulation.ox ***/
	rndmged(const n, const k, const df);
	rndmskewedt(const n, const k, const df, const xi);
	Simulate_GARCH(const omega, const alpha,const beta, const z, const discard, const y, const sigma2);
	Simulate_GJR(const omega, const alpha,const beta, const gamma, const z, const discard, const y, const sigma2);
	Simulate_APARCH(const omega, const alpha,const beta, const gamma, const delta, const z, const discard, const y, const sigma2);
	Simulate_EGARCH(const omega, const alpha,const beta, const gamma, const z, const discard, const y, const sigma2);
	Simulate_FIGARCH_CHUNG(const omega, const phi,const beta, const d, const z, const discard, const y, const sigma2);
};

#endif /* GARCH_INCLUDED */
