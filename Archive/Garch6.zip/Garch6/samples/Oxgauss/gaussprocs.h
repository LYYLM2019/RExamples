namespace gauss
{
	gengarch(const omega,const alpha,const beta,const nu,const t_0,const t, const n);
	// add new procedures here
}
