﻿			  /////////////////////////////////							
			 //  G@RCH Package 6.0 for Ox  //	
			/////////////////////////////////

The G@RCH package requires Ox 5.

Versions history & improvements
===============================
v.6.0 : May, 2009
        - Bug fixed: G@RCH experienced convergence problems when returns were not expressed in %. This is now fixed.
v.5.1 : June, 20th, 2008.
	- The Mac OSX and Linux versions of G@RCH 5.1 are now available. 
	- Several tests have been added to the menu ’Descriptive Statistics’, i.e. the Variance Ratio test of Lo and MacKinlay (1988), 
	  the Runs test originally used by Fama (1965) and the Rescaled Range Tests of Mandelbrot (1972) and Lo (1991). 
	  These tests are described in Section 3.12. The size and power of these tests are studied through some Monte Carlo experiments.
          The Ox codes used for these simulations is available in the folder packages/Garch5/samples/ 
	- Bug fixed (thanks to Stefan De Wachter): Time-axis did not show the right time period when selecting a subsample. 
          The time-axis started from the beginning of the dataset, regardless of what the selected estimation sample was. 
	- Problem fixed: annoying Internet Explorer 7 warning about running ActiveX controls when running the OxMetrics help. 
	- Thanks to Robert A. Yaffee, failure rates for short position in the output of the Kupiec LR test are now labelled success rates. 
	- Thanks to Christian Conrad, non-negativity conditions for FIGARCH and HYGARCH models are implemented in the following examples: 
	  Stat_Constr_FIGARCH_Conrad_Haag_Check.ox and Stat_Constr_HYGARCH_Conrad_Check.ox for a FIGARCH and HYGARCH (1,d,1) respectively. 
	  While the conditions are tested on the estimated parameters in the previous two example files, the conditions are imposed during 
	  the estimation in the next two, i.e. Stat_Constr_FIGARCH_Conrad_Haag_Impose.ox and Stat_Constr_HYGARCH_Conrad_Impose.ox. 
v.5.00: September, 17th, 2007.
	- New documentation. See /doc/index.html.
	- The estimation of EGARCH-type models and ARCH-in-mean model has been considerably improved.
	- G@RCH now provides some simulation capabilities through the menu Monte-Carlo. GARCH, GJR, APARCH and EGARCH models are
	  available with an ARMA in the conditional mean and normal, student, GED or skewed student errors.
	  The simulated data can be plotted and stored in a separated dataset. 
	- Three unit root tests (ADF, KPSS and SP) and two long-memory tests (GPH and GSP) have been added
	  (available through the ‘descriptive statistics’ menu). 
	- A new function is provided to compute the statistics of Lee and Mykland (2006) to detect jumps at ultra-high frequency. 
	- Several multivariate GARCH models are available including the scalar BEKK, diagonal BEKK, RiskMetrics,
	  CCC, DCC, OGARCH and GOGARCH models. To estimate these models via Ox, import the mgarch class.
	  Several examples are given in /ox/packages/MGarch1/samples/. 
	- G@RCH also provides some specific multivariate miss-specification tests like a multivariate normality test,
	  Hosking’s portmanteau test, Li and McLead test, two constant correlation tests, etc. 
	- G@RCH also provides some functions to simulate BEKK, CCC and DCC models. 
	- A new feature of G@RCH 5.0 is that Ox code can be generated. The Model/Ox Batch Code command (or Alt+O)
	  activates a new dialog box called ’Generate Ox Code’ that allows the user to select an item for which to generate Ox code.
v.4.00: March, 17th, 2005.
	- New documentation. See /doc/index.html.
	- The professional version of G@RCH
	(distributed by Timberlake Consultants Ltd)
	is launched from GiveWin. Indeed, G@RCH Professional
	provides a friendly interface (with rolling menus) as well
	as some graphical features (through the graphical interface
	GiveWin).
	The console version (this version) does not support the
	graphical features of GiveWin. It requires an Ox
	executable and a text editor (like OxEdit).	
	- Several minor bugs corrected 
v.3.00: September, 27th, 2002.
	- Ox 3.20 compatible. 
	- The uncompiled source code is available. 
	- A new In-Mean option allows ARCH-in-mean effects.
	- Constrained optimization allowed using MaxSQPF.
	- Improved handling of tests.
	- Easier modification of the starting values.
	- Almost all the functions in GarchEstim.ox are independent of the code and can be deleted (see GarchEstimModified.ox for an example) 
	- Uses NumJacobianEx instead of ScoreContributions.
	- Several minor bugs corrected.
v.2.30: April, 22nd, 2002.
	- Ox 3.10 compatible.
	- New Modelclass in OxPack to allow the computation of tests to raw dataset, prior to estimation.
	- Improved OxPack interface.
	- Several minor bugs corrected. 
v.2.20: February, 26th, 2002.
	- The Hyperbolic GARCH (HYGARCH) of Davidson(2001) is available.
	- Improved forecasts, with new graphical options.  
	- Stationarity and positivity constraints are checked for most the models. 
	- All the GARCH models and all the tests can be called from external code.
	- Possibility to fix some parameters at any defined value. 
	  It allows thus to estimate, for instance, an AR(2) model with only lag 2 estimated (by fixing the AR(1) parameter to 0)
	- Possibility to save graphics when using the "Light Version" without GiveWin. 
v.2.11: September, 3rd, 2001.
	- Minor bugs corrected. 
v.2.10: August, 23rd, 2001.
	- Ox 3.0 compatible. 
	- The GARCH models functions can be called from external code. 
	- The startingvalues.xls has been replaced by startingvalues.txt.  
	- The estimated parameters and their standard deviations can now be stored in an external file. 
	- The number of cells in the graphic of the Pearson goodness-of-fit test can be fixed by the user. 
v.2.00: May, 7th, 2001.
	- Skewed Student-t distribution
	- One-step ahead forecast
	- 10 forecasts errors measures
	- Pearson goodness-of-fit test
	- Nyblom stability test 
	- Probability integral transform
	- Numerous other improvements (faster procedures, improved storage, ...)
v.1.12: December, 15th, 2000.
	- includes the Nyblom Test of Stability and the Adjusted Pearson Goodness-of-Fit Test.
	- allows Exclusion Restrictions and Linear Restrictions (only with OxPack). 
v.1.11: November, 20th, 2000.
	- E(|z|) has been corrected for both the Student-t and the GED distribution.
	- Condition of existence for expected variance & expected absolute residuals in the APARCH is checked (Ding et al.[1993], Eq.18, see References in the tutorial)
v.1.10:	October 28th, 2000
	- improved IGARCH procedure
	- includes FIAPARCH estimation with Chung(1999)'s approach (see references in garch.ps)
	- faster procedures for GARCH, APARCH & GJR.
	- minor bugs corrected	
v.1.00: September 4th, 2000


REDISTRIBUTION OF A MODIFIED VERSION OF ANY OF THESE FILES IS STRICTLY PROHIBITED                              

The only official location for updates and news about this package is                      
http://www.garch.org

Contact
=======
For any information about the package, or to report any bugs, please contact us:


Sébastien LAURENT
Associate Professor in Econometrics 
Université Notre-Dame de la Paix Namur
Rempart de la vièrge, 8 
B-5000 NAMUR
BELGIUM
e-mail: Sebastien.Laurent@fundp.ac.be 
phone : +32 (0)81 72 48 69
fax   : +32 (0)81 72 48 40 

or 

http://www.garch.org


Important Notice
================
THIS SOFTWARE AND SOURCE CODE ARE DISTRIBUTED "AS IS" AND WITHOUT WARRANTIES AS
TO PERFORMANCE OF MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR
IMPLIED. BECAUSE OF THE VARIOUS HARDWARE AND SOFTWARE ENVIRONMENTS INTO WHICH
THESE ITEMS MAY BE PUT, NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE IS
OFFERED.

WHILE EVERY EFFORT HAS BEEN MADE TO TEST THE PRODUCT IN A WIDE VARIETY OF
OPERATING ENVIRONMENTS, GOOD PROCEDURE DICTATES THAT ANY PROGRAM BE THOROUGHLY
TESTED WITH NON-CRITICAL DATA BEFORE RELYING ON IT. THE USER MUST ASSUME THE
ENTIRE RISK OF USING THE PROGRAM. ANY LIABILITY OF THE AUTHOR WILL BE LIMITED
EXCLUSIVELY TO PRODUCT REPLACEMENT.

COPYRIGHT 2000-2008, S.Laurent.